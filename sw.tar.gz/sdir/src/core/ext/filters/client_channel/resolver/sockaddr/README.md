Support for resolving ipv4:, ipv6:, unix: schemes
